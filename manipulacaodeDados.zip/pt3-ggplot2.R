install.packages("ggplot2")
library(ggplot2)

grafico1<-ggplot(base2007,aes(x=continent,y=lifeExp))
ggplot(base2007,aes(x=continent,y=lifeExp)) + geom_boxplot()
ggplot(base2007,aes(x=continent,y=lifeExp)) + geom_point()
ggplot(base2007,aes(x=continent,y=lifeExp)) + geom_violin()

ggplot(base2007,aes(x=continent, y=lifeExp))+geom_boxplot()+
  ggtitle("Boxplot da expectativa de vida")+xlab("Continentes")+
  ylab("Expectativa de vida")

ggplot(baseProx,aes(x=year, y=gdpPercap))+geom_point()
ggplot(baseProx,aes(x=year, y=gdpPercap))+geom_line()

ggplot(baseProx,aes(x=year, y=gdpPercap, col = country))+geom_point()
ggplot(baseProx,aes(x=year, y=gdpPercap, col = country))+geom_line()
ggplot(baseProx,aes(x=year, y=gdpPercap, col = country))+geom_line(size=1.2)

ggplot(base2007,aes(x=gdpPercap,y=lifeExp))+ geom_point() 

ggplot(base2007,aes(x=gdpPercap,y=lifeExp))+ geom_point() + geom_smooth()

ggplot(base2007,aes(x=gdpPercap,y=lifeExp,col=continent))+ geom_point() 

ggplot(base2007,aes(x=gdpPercap,y=lifeExp,col=continent,size=pop))+ geom_point() 

ggplot(base2007,aes(x=gdpPercap,y=lifeExp,color=continent))+ geom_point() + geom_smooth(method='lm')

ggplot(base2007,aes(x=gdpPercap,y=lifeExp,col=continent))+ geom_point() + geom_smooth(method='lm') + facet_wrap(~continent)

ggplot(base2007,aes(x=lifeExp))+ geom_histogram()
ggplot(base2007,aes(x=lifeExp))+ geom_density()

ggplot(base2007,aes(x=lifeExp, col=continent))+ geom_density()
ggplot(base2007,aes(x=lifeExp, col=continent, fill = continent))+ geom_density()
ggplot(base2007,aes(x=lifeExp, col=continent, fill = continent))+ geom_density(alpha=0.5)

ggplot(base2007,aes(x=lifeExp, col=continent))+ geom_density(alpha=0.5)+ facet_wrap(~continent)

ggplot(base2007,aes(x=lifeExp, fill=continent))+ geom_histogram(alpha=0.5)+ facet_wrap(~continent)


base2007%>%
  filter(continent!="Oceania")%>%
  ggplot(aes(x=lifeExp, col=continent, fill = continent))+ geom_density(alpha=0.5)

