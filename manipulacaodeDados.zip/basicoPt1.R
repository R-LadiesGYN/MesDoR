# Operações básicas
5 + 5
10 - 6
10*2
5/2
5**2
sqrt(16)
5*(50-45) 

# Operações básicas e atribuicoes
x <- 5 + 5
y <- 10 - 16
a <- 9
soma <- a + x 
nome <- "daniel"
certo <- TRUE

# Operações básicas
pesoDaniel <- 79
alturaDaniel <- 1.78

imcDaniel <- pesoDaniel/alturaDaniel**2

# trabalhando com vetores
pesos <- c(65, 95, 75, 77, 80, 68)
alturas <- c(1.60, 1.78, 1.80, 1.68, 1.72, 1.65) 
imc <- pesos/alturas**2
imc

help(round)

round(imc, 2)
imc <- round(imc, 2) #estou sobrescrevendo um vetor 
imc                  #arredondado sobre ele mesmo

Matriz<-cbind(pesos,alturas,imc)
Matriz

rownames(Matriz)<-c("Alice","Gilmar","Cecilia",
                    "Bianca","Valentina","Augusto")
Matriz

