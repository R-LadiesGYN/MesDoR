install.packages("dplyr")
install.packages("gapminder")
library(dplyr)
library(gapminder)

basePaises<-gapminder
codigo<-country_codes

str(basePaises)
head(basePaises)
tail(basePaises, n = 10)

glimpse(basePaises)
View(basePaises)

basePaises%>%
  distinct(continent)

basePaises%>%
  filter(continent == "Asia")

basePaises%>%
  filter(continent == "Americas" & year>1990) 

basePaises%>%
  filter(continent != "Oceania")

# O mais legal é que você pode armazenar essas consultas em novos objetos
# basta usar uma atribuição

baseAsia <- basePaises%>%
  filter(continent == "Asia")
basePaises%>%
  select(year,country,gdpPercap)

basePaises%>%
  select(-lifeExp)

basePaises%>%
  filter(continent == "Americas" & year>1990)%>%
  select(year,country,gdpPercap) 

basePaises <- basePaises%>%
  mutate(GDP = gdpPercap * pop)

base2007 <- basePaises%>%
  filter(year == 2007) %>%
  mutate(porte = if_else(pop>median(pop),"G","P"))

base2007<-base2007%>%
  mutate(classGPC = case_when(
    gdpPercap < 1625 ~ "Baixo",
    gdpPercap >= 1625 & gdpPercap <18008 ~ "Medio",
    gdpPercap >= 18008 ~ "Alto")) # til

base2007%>%
  group_by(classGPC)%>%
  count()


basePaises%>%
  group_by(country)%>%
  summarize(meanLE=mean(lifeExp),meanPop=mean(pop),
            meanGpc=mean(gdpPercap))

baseContinentes <- basePaises %>%
  group_by(continent,year)%>%
  summarize(meanLE=mean(lifeExp),meanPop=mean(pop),
            meanGpc=mean(gdpPercap))

#Adicione a base codigo e idh ao global environment

basePaisCod <- basePaises%>%
  inner_join(codigo,by="country")

baseCompleta <- basePaisCod %>%
  inner_join(paisesIDH,by=c("country"="paises"))

Paisesfora <- paisesIDH%>%
  anti_join(basePaises,by=c("paises"="country"))

Paisesfora <-base2007%>%
  anti_join(basePaises,by=c("country"="paises"))


